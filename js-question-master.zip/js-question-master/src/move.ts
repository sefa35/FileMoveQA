// Please update this type as same as with the data shape.
type List = unknown;

export default function move(list: List, source: string, destination: string): List {
  throw new Error('Not implemented');
}
